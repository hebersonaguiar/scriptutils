<?php 

Route::post('sendmessage', 'chatController@sendMessage');

Route::get('twitterUserTimeline', 'TwitterController@twitterUserTimeLine');
Route::post('tweet', ['as'=>'post.tweet','uses'=>'TwitterController@tweet']);

Route::get('itemCRUD', ['as'=> 'itemCRUD.index', 'uses'=>'ItemCRUDController@index']);
Route::get('itemCRUD/create', ['as'=> 'itemCRUD.create', 'uses'=>'ItemCRUDController@create']);
Route::post('itemCRUD/store', ['as'=> 'itemCRUD.store', 'uses'=>'ItemCRUDController@store']);
Route::get('itemCRUD/show/{id}', ['as'=> 'itemCRUD.show', 'uses'=>'ItemCRUDController@show']);
Route::get('itemCRUD/{id}/edit', ['as'=> 'itemCRUD.edit', 'uses'=>'ItemCRUDController@edit']);
Route::patch('itemCRUD/update/{id}', ['as'=> 'itemCRUD.update', 'uses'=>'ItemCRUDController@update']);
Route::delete('itemCRUD/destroy/{id}', ['as'=> 'itemCRUD.destroy', 'uses'=>'ItemCRUDController@destroy']);

//#<?php
//#
//#/*
//#|--------------------------------------------------------------------------
//#| Web Routes
//#|--------------------------------------------------------------------------
//#|
//#| Here is where you can register web routes for your application. These
//#| routes are loaded by the RouteServiceProvider within a group which
//#| contains the "web" middleware group. Now create something great!
//#|
//#*/
//#
//#Route::get('/', function () {
//#    return view('welcome');
//#});
