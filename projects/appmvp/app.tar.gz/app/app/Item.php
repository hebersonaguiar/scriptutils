<?php
namespace App;


use Illuminate\Database\Eloquent\Model;


class Item extends Model
{


    public $fillable = ['cpf','firstname','lastname','login','department','rg','room','phone','ticketid','ticketnumber'];


}
